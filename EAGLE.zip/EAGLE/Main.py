import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget, QTabWidget, QLabel, QSplashScreen
from PyQt5.QtGui import QIcon, QPixmap
from PyQt5.QtCore import QTimer, Qt
from sub_codes.home_tab import create_home_tab_layout
from sub_codes.merge_tab import create_merge_tab_layout
from sub_codes.analysis_tab import create_analysis_tab_layout
from sub_codes.help_tab import create_help_tab_layout

class StartupWindow(QSplashScreen):
    def __init__(self):
        super().__init__()
        self.setPixmap(QPixmap("LOGO.png"))  # Set the pixmap to the logo
        self.showMessage("Welcome to E.A.G.L.E", alignment=Qt.AlignBottom | Qt.AlignCenter, color=Qt.white)

    def mousePressEvent(self, event):
        # Override the mousePressEvent to allow the splash screen to close on mouse click
        self.close()
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("E.A.G.L.E Tool")
        self.setWindowIcon(QIcon("LOGO.png"))
        self.resize(800, 600)
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout()
        central_widget.setLayout(layout)

        self.tab_widget = QTabWidget()
        layout.addWidget(self.tab_widget)

        # Add tabs
        self.add_home_tab()
        self.add_merge_tab()
        self.add_analysis_tab()
        self.add_help_tab()

    def add_home_tab(self):
        home_widget = create_home_tab_layout()
        self.tab_widget.addTab(home_widget, "Home")

    def add_merge_tab(self):
        merge_widget = create_merge_tab_layout()
        self.tab_widget.addTab(merge_widget, "Merge")

    def add_analysis_tab(self):
        analysis_widget = create_analysis_tab_layout()
        self.tab_widget.addTab(analysis_widget, "Analysis")

    def add_help_tab(self):
        help_widget = create_help_tab_layout()  # Call the function from help_tab.py
        self.tab_widget.addTab(help_widget, "Help")


def main():
    app = QApplication(sys.argv)
    # Show the startup window
    startup_window = StartupWindow()
    startup_window.show()
    QTimer.singleShot(3000, startup_window.close)  # Close the startup window after 3000 ms (3 seconds)

    window = MainWindow()
    QTimer.singleShot(3000, window.show)  # Show the main window after the startup window closes

    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
