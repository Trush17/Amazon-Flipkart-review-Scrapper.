import requests
from bs4 import BeautifulSoup
from datetime import datetime
import re
import pandas as pd
import time

def amazon_scrape(urls):
    # Header to set the requests as a browser request
    headers = {
        'authority': 'www.amazon.in',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'accept-language': 'en-US,en;q=0.9,bn;q=0.8',
        'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="102", "Google Chrome";v="102"',
        'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36'
    }

    # Extract Data as HTML object from Amazon Review page
    def reviewsHtml(url, len_page):
        soups = []

        for page_no in range(1, len_page + 1):
            params = {
                'ie': 'UTF8',
                'reviewerType': 'all_reviews',
                'pageNumber': page_no,
            }
            response = requests.get(url, headers=headers, params=params)
            soup = BeautifulSoup(response.text, 'lxml')
            soups.append(soup)

        return soups

    # Determine category based on the product name
    def determineCategory(product_name):
        # Extract three-digit numbers from the product name
        numbers = [int(num) for num in re.findall(r'\b\d{3}\b', product_name)]

        # Check if any of the three-digit numbers is greater than 180
        if any(num > 180 for num in numbers):
            return 'UVR'

        # If no three-digit number is found or all are <= 180, determine the category as before
        if 'scooter' in product_name.lower():
            return 'SC'
        elif 'bike' in product_name.lower():
            return 'MC'
        else:
            return 'PCR'

    # Determine sentiment based on the rating
    def determineSentiment(rating):
        if rating < 3:
            return 'Negative'
        elif rating == 3:
            return 'Neutral'
        else:
            return 'Positive'

    # Grab Reviews: name, description, date, stars, title, category, and sentiment from HTML
    def getReviews(html_data):
        data_dicts = []
        boxes = html_data.select('div[data-hook="review"]')

        product_link_element = html_data.select_one('a[data-hook="product-link"]')
        if product_link_element:
            product_name = product_link_element.text.strip()
            company_name = product_link_element.text.strip().split()[0]
            category = determineCategory(product_name)
        else:
            product_name = 'N/A'
            company_name = 'N/A'
            category = 'Unknown'

        current_month = datetime.now().month
        previous_month = current_month - 1 if current_month != 1 else 12  # Get previous month

        for box in boxes:
            try:
                datetime_str = box.select_one('[data-hook="review-date"]').text.strip().split(' on ')[1]
                review_date = datetime.strptime(datetime_str, '%d %B %Y')

                if review_date.month == previous_month:
                    name = box.select_one('[class="a-profile-name"]').text.strip()
                    rating = float(box.select_one('[data-hook="review-star-rating"]').text.strip().split(' out')[0])
                    title = box.select_one('[data-hook="review-title"]').text.strip().split('\n')[1]
                    description = box.select_one('[data-hook="review-body"]').text.strip()
                    sentiment = determineSentiment(rating)

                    data_dict = {
                        'Date': review_date.strftime("%b %y"),
                        'Name': name,
                        'Title': title,
                        'Description': description,
                        'Product': product_name,
                        'Company': company_name,
                        'Category': category,
                        'Rating': rating,
                        'Sentiment': sentiment,
                        'Platfrom': 'Amazon'
                    }

                    data_dicts.append(data_dict)
            except Exception as e:
                pass

        return data_dicts

    # Data Processing

    # Empty List to Hold all reviews data
    all_reviews = []

    # Iterate through the list of URLs
    for i, url in enumerate(urls):
        try:
            # Grab all HTML
            html_datas = reviewsHtml(url, len_page=4)

            # Iterate all HTML pages
            for html_data in html_datas:
                review = getReviews(html_data)
                all_reviews += review

            time.sleep(2)

        except Exception as e:
            print(f"Error scraping Amazon reviews for URL: {url}")
            print(e)

    # Create a dataframe with all reviews data
    df_reviews = pd.DataFrame(all_reviews)

    # Remove duplicate reviews based on Name, Title, and Date criteria
    df_reviews.drop_duplicates(subset=['Name', 'Title', 'Date'], keep='first', inplace=True)

    return df_reviews
