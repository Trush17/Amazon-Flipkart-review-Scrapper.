import os
from PyQt5.QtWidgets import QWidget, QVBoxLayout
from PyQt5.QtWebEngineWidgets import QWebEngineView
from PyQt5.QtCore import QUrl

def create_help_tab_layout():
    help_widget = QWidget()
    layout = QVBoxLayout()
    help_widget.setLayout(layout)

    # Create a QWebEngineView to display the HTML content
    webview = QWebEngineView()
    layout.addWidget(webview, stretch=1)  # Set stretch factor to 1 to make the webview occupy all available space

    # Load the HTML file into the QWebEngineView
    html_file = os.path.abspath("EAGLE_SOP.html")
    webview.load(QUrl.fromLocalFile(html_file))

    return help_widget
