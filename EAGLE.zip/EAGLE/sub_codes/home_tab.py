from PyQt5.QtWidgets import QVBoxLayout, QWidget, QRadioButton, QLineEdit, QPushButton, QLabel, QTableWidget, QTableWidgetItem, QFileDialog, QHBoxLayout
from PyQt5.QtCore import pyqtSlot
from threading import Thread
import pandas as pd
from sub_codes.amazon_scraper import amazon_scrape
from sub_codes.flipkart_scraper import flipkart_scrape

def create_home_tab_layout():
    # Create a widget for the Home tab
    home_widget = QWidget()
    layout = QVBoxLayout()
    home_widget.setLayout(layout)

    # Add radio buttons for Amazon and Flipkart
    amazon_radio = QRadioButton("Amazon")
    flipkart_radio = QRadioButton("Flipkart")
    layout.addWidget(amazon_radio)
    layout.addWidget(flipkart_radio)

    # Add a text box for pasting URLs
    url_textbox = QLineEdit()
    url_textbox.setPlaceholderText("Paste URLs here separated by commas")
    url_textbox.setFixedSize(800, 50)
    layout.addWidget(url_textbox)

    # Add a layout for buttons
    button_layout = QHBoxLayout()

    # Add a button to initiate scraping
    scrape_button = QPushButton("Scrape Reviews")
    button_layout.addWidget(scrape_button)

    # Add an Export button
    export_button = QPushButton("Export")
    button_layout.addWidget(export_button)

    # Add a Clear button
    clear_button = QPushButton("Clear")
    button_layout.addWidget(clear_button)

    layout.addLayout(button_layout)

    # Add a label to display the status of scraping process
    status_label = QLabel("Status: Idle")
    layout.addWidget(status_label)

    # Add a table widget to display the scraped reviews
    table = QTableWidget()
    layout.addWidget(table)

    # Function to handle button click event for clearing
    def clear_data():
        url_textbox.clear()
        table.clearContents()
        table.setRowCount(0)

    # Connect button click event to the handler function for clearing
    clear_button.clicked.connect(clear_data)

    # Function to handle button click event for scraping
    @pyqtSlot()
    def on_scrape_button_clicked():
        # Get the selected platform (Amazon or Flipkart)
        platform = "Amazon" if amazon_radio.isChecked() else "Flipkart"
        # Get the URLs from the text box
        urls = url_textbox.text().strip().split(',')

        # Disable the button to prevent multiple clicks during scraping
        scrape_button.setEnabled(False)
        export_button.setEnabled(False)  # Disable export button during scraping
        clear_button.setEnabled(False)   # Disable clear button during scraping
        status_label.setText(f"Status: Scraping {platform} reviews...")

        # Perform scraping in a separate thread to prevent blocking the GUI
        def scrape_reviews():
            # Call the scraping function based on the selected platform
            if platform == "Amazon":
                combined_reviews = []
                for url in urls:
                    reviews_df = amazon_scrape([url.strip()])
                    combined_reviews.append(reviews_df)
                all_reviews_df = pd.concat(combined_reviews)
            elif platform == "Flipkart":
                combined_reviews = []
                for url in urls:
                    reviews_df = flipkart_scrape([url.strip()])
                    combined_reviews.append(reviews_df)
                all_reviews_df = pd.concat(combined_reviews)

            # Update the table with the scraped data
            update_table(table, all_reviews_df)

            # Update status label and re-enable the buttons after scraping is finished
            status_label.setText("Status: Idle")
            scrape_button.setEnabled(True)
            export_button.setEnabled(True)
            clear_button.setEnabled(True)

        # Start scraping in a separate thread
        scraping_thread = Thread(target=scrape_reviews)
        scraping_thread.start()

    # Connect button click event to the handler function for scraping
    scrape_button.clicked.connect(on_scrape_button_clicked)

    # Function to handle button click event for exporting
    @pyqtSlot()
    def on_export_button_clicked():
        # Get the table data
        table_data = [[table.item(row, column).text() for column in range(table.columnCount())] for row in range(table.rowCount())]

        # Get a file path using a file dialog
        file_path, _ = QFileDialog.getSaveFileName(home_widget, "Save Reviews", "", "CSV files (*.csv);;Excel files (*.xlsx *.xls)")

        if file_path:
            # Determine the file format based on the file extension
            if file_path.endswith('.csv'):
                # Write the table data to a CSV file
                df = pd.DataFrame(table_data, columns=[table.horizontalHeaderItem(i).text() for i in range(table.columnCount())])
                df.to_csv(file_path, index=False)
            elif file_path.endswith('.xlsx') or file_path.endswith('.xls'):
                # Write the table data to an Excel file
                df = pd.DataFrame(table_data, columns=[table.horizontalHeaderItem(i).text() for i in range(table.columnCount())])
                df.to_excel(file_path, index=False)

    # Connect button click event to the handler function for exporting
    export_button.clicked.connect(on_export_button_clicked)

    return home_widget


def update_table(table, reviews_df):
    table.setRowCount(reviews_df.shape[0])
    table.setColumnCount(reviews_df.shape[1])
    table.setHorizontalHeaderLabels(reviews_df.columns)

    for i in range(reviews_df.shape[0]):
        for j in range(reviews_df.shape[1]):
            table.setItem(i, j, QTableWidgetItem(str(reviews_df.iloc[i, j])))
