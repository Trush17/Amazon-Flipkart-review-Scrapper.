from PyQt5.QtWidgets import QVBoxLayout, QHBoxLayout, QWidget, QPushButton, QLineEdit, QFileDialog, QLabel, QTableWidget, QTableWidgetItem
from PyQt5.QtCore import pyqtSlot
import pandas as pd

def create_merge_tab_layout():
    merge_widget = QWidget()
    layout = QVBoxLayout()
    merge_widget.setLayout(layout)

    # Add input field and buttons to select CSV files, merge files, and save merged file
    csv_files_input = QLineEdit()
    csv_files_input.setPlaceholderText("Select CSV files to merge")
    layout.addWidget(csv_files_input)

    # Create a QHBoxLayout to contain the Browse and Merge buttons side by side
    button_layout = QHBoxLayout()
    layout.addLayout(button_layout)

    browse_button = QPushButton("Browse")
    button_layout.addWidget(browse_button)

    merge_button = QPushButton("Merge Files")
    button_layout.addWidget(merge_button)

    # Add the Save Merged File button
    save_button = QPushButton("Save Merged File")
    button_layout.addWidget(save_button)

    # Add the Clear button
    clear_button = QPushButton("Clear")
    button_layout.addWidget(clear_button)

    # Add label to display merge output
    merge_output_label = QLabel("")
    layout.addWidget(merge_output_label)

    # Add table widget to display merged data
    merged_table = QTableWidget()
    layout.addWidget(merged_table)

    @pyqtSlot()
    def on_browse_button_clicked():
        file_dialog = QFileDialog()
        file_dialog.setFileMode(QFileDialog.ExistingFiles)
        file_dialog.setNameFilter("Excel files (*.xls *.xlsx *.xlsm *.xlsb *.odf *.ods *.odt);;CSV files (*.csv)")
        if file_dialog.exec_():
            file_paths = file_dialog.selectedFiles()
            csv_files_input.setText(";".join(file_paths))

    browse_button.clicked.connect(on_browse_button_clicked)

    @pyqtSlot()
    def on_merge_button_clicked():
        try:
            file_paths = csv_files_input.text().split(";")
            global merged_data
            merged_data = merge_csv_files(file_paths)
            merge_output_label.setText("Files Merged Successfully!")

            # Update the table with the merged data
            update_table(merged_table, merged_data)

        except Exception as e:
            merge_output_label.setText(f"Error while merging files: {str(e)}")

    merge_button.clicked.connect(on_merge_button_clicked)

    @pyqtSlot()
    def on_save_button_clicked(merged_data):  # Pass merged_data as an argument
        if not merged_table.model():
            merge_output_label.setText("Merge files first!")
            return

        save_path, _ = QFileDialog.getSaveFileName(merge_widget, "Save Merged File", "",
                                                   "Excel files (*.xlsx *.xls *.xlsm *.xlsb *.ods *.odf *.odt);;CSV files (*.csv)")
        if save_path:
            try:
                if save_path.endswith(".csv"):
                    merged_data.to_csv(save_path, index=False)
                else:
                    merged_data.to_excel(save_path, index=False)
                merge_output_label.setText("Merged File Saved Successfully!")
            except Exception as e:
                merge_output_label.setText(f"Error while saving merged file: {str(e)}")

    save_button.clicked.connect(lambda: on_save_button_clicked(merged_data))  # Connect with lambda to pass merged_data

    # Function to handle button click event for clearing
    def clear_data():
        csv_files_input.clear()
        merged_table.clearContents()
        merged_table.setRowCount(0)
        merge_output_label.setText("")

    # Connect button click event to the handler function for clearing
    clear_button.clicked.connect(clear_data)

    return merge_widget


def merge_csv_files(file_paths):
    dataframes = [pd.read_csv(file) for file in file_paths]
    merged_df = pd.concat(dataframes, ignore_index=True)
    return merged_df

def update_table(table, data):
    table.setColumnCount(len(data.columns))
    table.setRowCount(len(data))

    for i in range(len(data)):
        for j in range(len(data.columns)):
            table.setItem(i, j, QTableWidgetItem(str(data.iloc[i, j])))
