import sys
import os
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QApplication, QMainWindow
from PyQt5.QtWebEngineWidgets import QWebEngineView
from PyQt5.QtCore import QUrl


def create_analysis_tab_layout():
    analysis_widget = QWidget()
    layout = QVBoxLayout()
    analysis_widget.setLayout(layout)

    # Add PivotTable.js Demo to the Analysis tab
    webview = QWebEngineView()
    setup_webview(webview)
    layout.addWidget(webview)

    return analysis_widget


def setup_webview(webview):

    html_file = os.path.abspath("pivottable-master/examples/pivottable.html")
    webview.load(QUrl.fromLocalFile(html_file))


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = QMainWindow()
    window.setCentralWidget(create_analysis_tab_layout())
    window.show()
    sys.exit(app.exec_())
