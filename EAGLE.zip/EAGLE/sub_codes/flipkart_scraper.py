import requests
from bs4 import BeautifulSoup
from datetime import datetime, timedelta
import re
import pandas as pd
import time

def flipkart_scrape(urls):
    # Header to set the requests as a browser request
    headers = {
        'authority': 'www.flipkart.com',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'accept-language': 'en-US,en;q=0.9,bn;q=0.8',
        'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="102", "Google Chrome";v="102"',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36'
    }

    # Function to extract HTML objects from Flipkart Review pages
    def reviewsHtml(url, len_page):
        soups = []

        for page_no in range(1, len_page + 1):
            # Make the request using the correct URL format for pagination
            response = requests.get(url.format(page_no), headers=headers)
            soup = BeautifulSoup(response.content, 'html.parser')
            soups.append(soup)

        return soups

    # Function to extract reviews' details from HTML
    def getReviews(html_data):
        data_dicts = []
        boxes = html_data.find_all('div', class_='col _2wzgFH K0kLPL')

        # Extract product name and first word for the company name
        product_name_element = html_data.find('div', class_='_1AtVbE col-10-12')
        product_name_text = product_name_element.text.strip().replace(' Reviews', '') if product_name_element else 'N/A'
        product_name = product_name_text.split() if product_name_text != 'N/A' else 'N/A'
        company_name = product_name[0] if product_name != 'N/A' else 'N/A'

        # Determine category based on the product name
        if '4 Wheeler' in product_name_text:
            # Extract three-digit numbers from the product name
            numbers = [int(num) for num in re.findall(r'\b\d{3}\b', product_name_text)]
            category = 'UVR' if any(num > 180 for num in numbers) else 'PCR'
        elif any(word in product_name_text for word in ['Two Wheeler', 'Bike']):
            # Check if "Front & Rear" is found in the product name
            if 'Front & Rear' in product_name_text:
                category = 'SC'
            else:
                category = 'MC'
        else:
            category = 'Unknown'

        for box in boxes:
            name_elem = box.find('p', class_='_2sc7ZR _2V5EHH')
            rating_elem = box.find('div', class_='_3LWZlK _1BLPMq') or box.find('div', class_='_3LWZlK _1rdVr6 _1BLPMq')
            title_elem = box.find('p', class_='_2-N8zT')
            desc_elem = box.find('div', class_='t-ZTKy')

            if name_elem and rating_elem and title_elem and desc_elem:
                name = name_elem.text.strip()
                rating = float(rating_elem.text.strip())
                title = title_elem.text.strip()
                description = desc_elem.text.strip()

                review_text = box.text.strip()
                days_ago_pattern = re.findall(r'\d+ days? ago', review_text)

                if days_ago_pattern:
                    days_ago = int(re.findall(r'\d+', days_ago_pattern[0])[0])
                    review_date = datetime.now() - timedelta(days=days_ago)

                    # Logic to filter only previous month's reviews
                    current_date = datetime.now()
                    previous_month = current_date.replace(day=1) - timedelta(days=1)
                    if review_date.year == previous_month.year and review_date.month == previous_month.month:
                        review_date_formatted = review_date.strftime("%b %y")
                        sentiment = 'Positive' if '_3LWZlK _1BLPMq' in str(
                            rating_elem) else 'Negative' if '_3LWZlK _1rdVr6 _1BLPMq' in str(
                            rating_elem) else 'Neutral' if rating == 3 else 'Not Available'

                        # Remove "READ MORE" from description
                        description = re.sub(r'READ MORE', '', description)

                        data_dict = {
                            'Date': review_date_formatted,
                            'Name': name,
                            'Title': title,
                            'Description': description,
                            'Product': product_name_text,
                            'Company': company_name,
                            'Category': category,
                            'Rating': rating,
                            'Sentiment': sentiment,
                            'Platfrom': 'Flipkart'

                        }

                        data_dicts.append(data_dict)

        return data_dicts

    # Data Processing
    all_reviews = []

    # Iterate through the list of URLs
    for i, url in enumerate(urls):
        # Grab all HTML
        html_datas = reviewsHtml(url, len_page=1)

        # Iterate all HTML pages
        for html_data in html_datas:
            review = getReviews(html_data)
            all_reviews += review

        time.sleep(2)

    # Create a dataframe with all reviews data
    df_reviews = pd.DataFrame(all_reviews)

    # Remove duplicate reviews based on Name, Title, and Date criteria
    df_reviews.drop_duplicates(subset=['Name', 'Title', 'Date'], keep='first', inplace=True)

    return df_reviews
